This repo contains a collection of snippets to use with the NERD snippets
plugin (http://github.com/scrooloose/nerdsnippets).

It contains:
* my personal snippets
* all the rails related snippets converted from textmate by Fabio Akita (http://github.com/akitaonrails)
* a bunch of python and php snippets by Gavin Gilmour (http://github.com/gaving)

support_functions.vim contains functions that are called from some of the
snippets. This file should be sourced somewhere like your vimrc or the same
place you do the rest of your snippet setup.
